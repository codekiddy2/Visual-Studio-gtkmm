#include "stdafx.h"

using namespace cryptopp;

int main()
{

	return 0;
}
