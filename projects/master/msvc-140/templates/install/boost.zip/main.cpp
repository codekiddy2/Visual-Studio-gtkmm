// main.cpp
// defines application entry point

#include "stdafx.h"


int main()
{
	return 0;
}
