#pragma once

// PCH includes
// TODO: modify or add more includes here for faster compilation and intellisense according to your needs


DW // disable warnings macro (to compile own code with W4 flag)

#include <boost\array.hpp>
#include <boost\bind.hpp>
#include <boost\asio.hpp>
#include <boost\date_time.hpp>
#include <boost\smart_ptr.hpp>
#include <boost\filesystem.hpp>

EW // enable warnings macro
